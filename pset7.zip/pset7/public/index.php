<?php
    // configuration
    require("../includes/config.php");

    // store an array of associative arrays (each containing name of stock, current price of stock, shares the user have, and symbol of stock) in $position
    $positions = [];
    $cash = number_format(CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"])[0]["cash"], 2);
    $stocks = CS50::query("SELECT symbol, shares FROM Data WHERE user_id = ?", $_SESSION["id"]);
    print_r($stocks);
    return;
    render("portfolio.php", ["stocks" => $stocks, "cash" => $cash, "title" => "Portfolio"]);
?>