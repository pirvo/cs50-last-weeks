<form action="deposit.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class="form-control" name="deposit" placeholder="Deposit Amount" type="number"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Make Deposit</button>
        </div>
    </fieldset>
</form>