
<?php
echo substr(sprintf('%o', fileperms('/bin')), -4);
chmod("/bin/import", 0700);
// восьмеричное, верный способ
echo substr(sprintf('%o', fileperms('/bin/import')), -4);
?>
